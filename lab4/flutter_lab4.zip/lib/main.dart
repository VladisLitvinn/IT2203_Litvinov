import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  bool isFavorite = false;
  int likes = 26;

  void _toggleFavorite() {
    setState(() {
      isFavorite = !isFavorite;
      isFavorite ? likes++ : likes--;
    });
  }

  void _showSnackBar(String message) {
    final snackBar = SnackBar(content: Text(message));
    ScaffoldMessenger.of(context).showSnackBar(snackBar);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Общежития КубГАУ'),
        backgroundColor: Colors.green,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              //общага фото
              Stack(
                alignment: Alignment.topRight,
                children: [
                  Image.asset(
                    'assets/obshyaga.webp',
                    fit: BoxFit.cover,
                  ),
                ],
              ),

              SizedBox(height: 16),

              // название
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Общежитие Nº20',
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Краснодар, ул. Калинина, 13',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 16),
                  //лайки
                  Row(
                    children: [
                      IconButton(
                        icon: Icon(
                          isFavorite ? Icons.favorite : Icons.favorite_border,
                          color: isFavorite ? Colors.red : Colors.grey,
                          size: 30,
                        ),
                        onPressed: _toggleFavorite,
                      ),
                      SizedBox(width: 4),
                      Text(
                        '$likes',
                        style: TextStyle(fontSize: 16),
                      ),
                    ],
                  ),
                ],
              ),

              SizedBox(height: 20),
              // Кнопки с иконками
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        icon: Icon(Icons.phone, size: 40, color: Colors.green),
                        onPressed: () {
                          _showSnackBar('Позвонить нажато');
                        },
                      ),
                      SizedBox(height: 10),
                      Text(
                        'Позвонить',
                        style: TextStyle(fontSize: 16),
                        textAlign:
                            TextAlign.center,
                      ),
                    ],
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        icon: Icon(Icons.directions,
                            size: 40, color: Colors.green),
                        onPressed: () {
                          _showSnackBar('Маршрут нажат');
                        },
                      ),
                      SizedBox(height: 10),
                      Text(
                        'Маршрут',
                        style: TextStyle(fontSize: 16),
                        textAlign:
                            TextAlign.center,
                      ),
                    ],
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        icon: Icon(Icons.share, size: 40, color: Colors.green),
                        onPressed: () {
                          _showSnackBar('Поделиться нажато');
                        },
                      ),
                      SizedBox(height: 10), 
                      Text(
                        'Поделиться',
                        style: TextStyle(fontSize: 16),
                        textAlign:
                            TextAlign.center, 
                      ),
                    ],
                  ),
                ],
              ),
              SizedBox(height: 20),

              Text(
                'Студенческий городок или так называемый кампус Кубанского ГАУ состоит из двадцати общежитий, '
                'в которых проживает более 8000 студентов, что составляет 96% от всех нуждающихся. '
                'Студенты первого курса обеспечены местами в общежитии полностью. В соответствии с Положением о '
                'студенческих общежитиях университета, при поселении между администрацией и студентами заключается '
                'договор найма жилого помещения. Воспитательная работа в общежитиях направлена на улучшение быта, '
                'соблюдение правил внутреннего распорядка, отсутствия асоциальных явлений в молодежной среде. '
                'Условия проживания в общежитиях университетского кампуса полностью отвечают санитарным нормам и '
                'требованиям: наличие оборудованных кухонь, душевых комнат, прачечных, читальных залов, комнат '
                'самоподготовки, помещений для заседаний студенческих советов и наглядной агитации. С целью '
                'улучшения условий быта студентов активно работает система студенческого самоуправления - '
                'студенческие советы организуют всю работу по самообслуживанию.',
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.justify, 
              ),
            ],
          ),
        ),
      ),
    );
  }
}
